using UnityEngine;

public class FireEffect : MonoBehaviour, IPoolable
{
    public void OnPool()
    {
       
    }
}
