using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Boss_02 : EnemyBase
{
    public float throwSpeed;
    public float throwDamage;

    public int spawnNum; //��� ��ȯ�ϴ���
    public float attackDelay; //������� ��ٸ��½ð�
    public float maxDist;

    private Transform playerTrm;
    private LineRenderer lineRenderer;

    public override void Start()
    {
        base.Start();

        playerTrm = GameManager.Instance.GetPlayer().transform;
        StartCoroutine(BossRoutine());

        if (lineRenderer == null)
        {
            lineRenderer = GetComponent<LineRenderer>();
        }

        PoolManager.CreatePool<Enemy_Bomb>("Enemy_Bomb", this.gameObject, spawnNum * 2);

        lineRenderer.startColor = new Color(1, 0, 0, 0.5f);
        lineRenderer.endColor = new Color(1, 0, 0, 0.5f);
        lineRenderer.startWidth = 0.2f;
        lineRenderer.endWidth = 0.2f;
    }

    private IEnumerator BossRoutine()
    {
        while (true)
        {
            float restTime = 2f;
            yield return new WaitForSeconds(restTime);
            int randPattern = Random.Range(0, 2);
            switch (randPattern)
            {
                case 0:
                    yield return AttackShoot(); //���
                    break;
                case 1:
                    yield return SpawnPattern();
                    break;
                default:
                    break;
            }
        }
    }

    private IEnumerator SpawnPattern() //����ȯ��
    {
        animator.SetTrigger("Attack");
        for (int i = 0; i < spawnNum; i++)
        {
            float range = 2f;
            var radian = i * (360 / (float)6) * Mathf.Deg2Rad;
            var x = (range) * Mathf.Sin(radian);
            var z = (range) * Mathf.Cos(radian);

            Vector3 createPos = new Vector3(x, 0, z) + transform.position;

            var bomb = PoolManager.GetItem<Enemy_Bomb>("Enemy_Bomb");
            bomb.transform.parent = transform.parent;
            bomb.transform.position = createPos;
            bomb.Revive();

            yield return new WaitForSeconds(0.1f);
        }
        yield return null;
    }

    private IEnumerator AttackShoot()
    {
        float time = Time.time;
        //���� ������ �׷������
        while (true)
        {
            transform.LookAt(GameManager.Instance.GetPlayer().transform);
            DrawDangerLine();
            if (Time.time - time > attackDelay)
            {
                break;
            }

            yield return null;
        }

        animator.SetTrigger("Attack");
        ThrowThing throwThing = PoolManager.GetItem<ThrowThing>("Ob_Enemy_Throw");
        throwThing.transform.position = transform.position + new Vector3(0, 0.5f, 0);
        throwThing.SetData(throwSpeed, throwDamage, GameManager.Instance.GetPlayer().transform.position);

        //�߻�


        lineRenderer.enabled = false;
        yield return null;
    }

    private void DrawDangerLine()
    {
        lineRenderer.enabled = true;
        lineRenderer.SetPosition(0, transform.position + new Vector3(0, 0.5f, 0));
        lineRenderer.SetPosition(1, transform.position + new Vector3(0, 0.5f, 0)     + transform.forward * maxDist);
    }
}
