using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NpcShop : NpcBase
{
    public override void DoAction()
    {
        //Show Panel
        print("열림");
    }
}
