using System;
using System.Collections.Generic;

[Serializable]
public class RecordListVO
{
    public List<RecordVO> list;
    public int count;
}
