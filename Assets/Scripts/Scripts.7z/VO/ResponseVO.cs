using System;

[Serializable]
public class ResponseVO
{
    public bool result;
    public string payload;
    public string msg;
}
